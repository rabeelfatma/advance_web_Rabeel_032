var express = require('express');
var router = express.Router();

/* Home page */
router.get('/', function(req, res) {
  res.render('index');
});

/* Signup page */
router.get('/signup', function(req, res) {
  res.render('signup');
});

/* Signup form submit */
router.post('/signup', function(req, res) {

  const {name,email,password} = req.body;

  console.log(name,email,password);

  res.send("Signup Successful");

});

module.exports = router;